import { Base } from './base';

export class Topic extends Base {
  name: string;
  description: string;
  bannerUrl: string;
}
