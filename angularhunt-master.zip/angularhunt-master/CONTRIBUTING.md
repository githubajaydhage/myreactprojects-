## Where to start?

There are many different ways to contribute to AngularHunt's development, just find the one that best fits with your skills. Examples of contributions we would love to receive include:

* Mobile compatibility (Responsiveness)[]
* Documentation improvements
* Bug reports
* Patch reviews
* UI enhancements

Responsiveness get's the highest priority so we'd love PR's related to that.

We’ll be more than happy to list your name/link in our README and give credits. It’s a nice opportunity for developers who want to experience how open source works or get more experience with this technology or just to connect with cool people and teams.

Let's build something cool together.
