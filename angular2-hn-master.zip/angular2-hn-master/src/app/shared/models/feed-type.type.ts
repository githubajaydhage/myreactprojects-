export type FeedType = 'poll' | 'story' | 'job';
