export class PollResult {
    points: number;
    content: string;
}
