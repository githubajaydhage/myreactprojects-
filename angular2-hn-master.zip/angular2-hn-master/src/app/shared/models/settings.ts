export interface Settings {
   showSettings: boolean;
   openLinkInNewTab: boolean;
   theme: string;
   titleFontSize: string;
   listSpacing: string;
}
