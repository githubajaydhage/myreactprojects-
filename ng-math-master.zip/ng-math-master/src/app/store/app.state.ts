import { GameSettings } from './settings.reducer';

export interface AppState {
  settings: GameSettings;
}
