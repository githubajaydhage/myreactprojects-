export * from './spinner/spinner';
export * from './bin/bin.component';
export * from './home/home.component';
export * from './about/about.component';
export * from './archive/archive.component';
