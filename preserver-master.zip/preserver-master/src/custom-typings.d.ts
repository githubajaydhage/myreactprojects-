declare module 'PouchDB' {
  namespace PouchDB {}
  export = PouchDB;
}
declare module '*';
declare var $: any;
