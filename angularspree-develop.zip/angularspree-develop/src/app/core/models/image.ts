export class Image {
  small: string;
  thumb: string;
  large: string;
  product_url: string;
}
