export class OptionType {
  id: string;
  name: string;
  presentation: string;
  position: string;
}
