export class Brand {
  id: string;
  image_url: string;
  name: string;
}
