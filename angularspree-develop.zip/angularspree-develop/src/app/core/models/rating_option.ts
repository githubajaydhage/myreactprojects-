export class RatingOption {
  id: string;
  code: string;
  position: number;
  value: number;
}
