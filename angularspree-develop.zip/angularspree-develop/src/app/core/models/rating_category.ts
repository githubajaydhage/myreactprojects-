export class RatingCategory {
  code: string;
  id: string;
  position: number;
}
