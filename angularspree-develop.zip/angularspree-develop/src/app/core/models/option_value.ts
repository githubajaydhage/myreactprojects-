export class OptionValue {
  id: string;
  name: string;
  presentation: string;
  option_type_name: string;
  option_type_id: number;
  option_type_presentation: string;
  option_type: any;
  value: any;
}
