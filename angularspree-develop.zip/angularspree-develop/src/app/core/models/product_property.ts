export class ProductProperty {
  id: number;
  product_id: number;
  property_id: number;
  value: string;
  property_name: string;
}
