export class ReviewList {
  position: number;
  value: string;
}
