import { Taxon } from './taxon';

export class Classification {
  taxon_id: number;
  position: number;
  taxon: Taxon;
}
