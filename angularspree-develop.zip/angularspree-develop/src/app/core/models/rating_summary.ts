import { ReviewList } from './review_list';

export class RatingSummary {
  average_rating: string;
  review_count: number;
  rating_list: Array<ReviewList>;
}
