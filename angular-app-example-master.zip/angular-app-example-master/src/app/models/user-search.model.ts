export class UserSearch {
  username?: string;
  email?: string;
  status?: string;
  createTimeRange?: string;
}
