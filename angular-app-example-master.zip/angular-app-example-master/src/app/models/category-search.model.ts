export class CategorySearch {
  key?: string;
  name?: string;
}
