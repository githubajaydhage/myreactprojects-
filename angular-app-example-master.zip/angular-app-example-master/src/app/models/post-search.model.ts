export class PostSearch {
  categoryId?: string;
  title?: string;
  authorId?: string;
  status?: string;
  createTimeRange?: string;
}
