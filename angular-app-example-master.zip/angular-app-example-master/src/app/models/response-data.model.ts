export class ResponseData {
  status: string;
  data: any;
}
