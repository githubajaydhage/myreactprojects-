export class Pagination {
  totalCount: number;
  pageCount: number;
  currentPage: number;
  perPage: number;
}
