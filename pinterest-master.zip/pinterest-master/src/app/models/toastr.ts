import { Base } from './base';
export class Toastr {

  constructor(public type: string, public title: string, public body: string) {

  }
}