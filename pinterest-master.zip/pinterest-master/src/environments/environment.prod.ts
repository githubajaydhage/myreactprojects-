export const environment = {
  production: true,
  apiEndpoint: 'https://pinwork-api.herokuapp.com/api/',
  socketEndpoint: 'wss://pinwork-api.herokuapp.com',
  basic_auth_token: btoa('api:password')
};
