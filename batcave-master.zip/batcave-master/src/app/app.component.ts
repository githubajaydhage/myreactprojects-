import { Component } from '@angular/core';
import '../assets/css/styles.css';

@Component({
  selector: 'batcave-app',
  template: '<router-outlet></router-outlet>'
})
export class AppComponent { }
