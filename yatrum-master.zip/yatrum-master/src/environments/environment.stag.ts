export const environment = {
   production: true,
   CLIENT_ID: "865ffa528b874fc3b755ee13b9a79037",
   API_ENDPOINT: "https://travel-api.herokuapp.com/", // add prod api link
   REDIRECT_URI: "https://aviabird.github.io/travel-app/instagram_authentication_callback_url", // add prod redirect url
   CLOUDINARY_CLOUD_NAME: 'zeus999',
   CLOUDINARY_UPLOAD_PRESET: 'blxtvppn'
};