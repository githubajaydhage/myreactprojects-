export const environment = {
 production: false,
    GOOGLE_API_KEY: 'AIzaSyAy22IfZS49CL9q3zpBKtdnEVRaX4cRTqw',
    CLIENT_ID: "865ffa528b874fc3b755ee13b9a79037",
    REDIRECT_URI: "http://localhost:4200/instagram_authentication_callback_url",
    CLOUDINARY_CLOUD_NAME: 'zeus999',
    CLOUDINARY_UPLOAD_PRESET: 'blxtvppn',
    API_ENDPOINT: 'http://localhost:3000'
};