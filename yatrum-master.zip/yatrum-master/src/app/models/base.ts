export class Base {
    id: string;
    created_at: string;
    updated_at: string;
}