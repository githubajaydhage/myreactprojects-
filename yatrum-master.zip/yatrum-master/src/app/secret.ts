export const Secrets  = {
  google_client_id: '1054215713241-vg92o2tufhb906j8gubq5tr0qusd4d34.apps.googleusercontent.com',
  facebook_client_id: '200197173792511'
}