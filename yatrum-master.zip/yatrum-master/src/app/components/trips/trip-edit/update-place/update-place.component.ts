import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'tr-update-place',
  templateUrl: './update-place.component.html',
  styleUrls: ['./update-place.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UpdatePlaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
